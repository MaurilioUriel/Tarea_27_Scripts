#Integrantes del equipo
#Alondra Castillo Gonzalez
#Erandy Yamileth Escanamé Balderas
#Maurilio Uriel García Culebra
 
import py2exe 
from distutils.core import setup

setup(
    console=['execute_pyautogui.py'], 
)

